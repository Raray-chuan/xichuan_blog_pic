<!--
#### Hi, 👋  I'm <a href="https://raray-chuan.github.io/xichuan_note" target="_blank">Xichuan </a>,If my note can help you in your work, please give me a following and a star!🍗
-->
<div >
    <!--<a href="https://raray-chuan.github.io/xichuan_note"><img height='50px' src="img/github-ico.gif" alt="xichuan_note" /></a>-->
    <!--<a href="https://raray-chuan.github.io/xichuan_note"><img height='50px' src="img/text.svg" alt="xichuan_note" /></a>-->
    <a href="https://raray-chuan.github.io/xichuan_note"><img height='50px' src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/github-ico.gif" alt="xichuan_note" /></a>
    &emsp;&emsp;
    <a href="https://raray-chuan.github.io/xichuan_note"><img height='50px' src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/text.svg" alt="xichuan_note" /></a>
  <span>&emsp;&emsp;</span>
</div>

<div align="center" >
    <!--<img  width="500px" order-radius="100px" src="img/head/cat/cat04.gif"/>-->
    <img  width="500px" order-radius="100px" src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/head/cat/cat04.gif"/>
</div>
<br>


## My Note📺🍻
<div align="">
<a href="https://github.com/Raray-chuan/xichuan_note">
  <img height="125px"  src="https://github-readme-stats.vercel.app/api/pin/?username=Raray-chuan&repo=xichuan_note&theme=panda&hide_border=false" />
</a>
</div>
<br>


## My Project🖥️🖱️
<div align="">
<a href="https://github.com/Raray-chuan/mini-spring">
  <img height="125px" src="https://github-readme-stats.vercel.app/api/pin/?username=Raray-chuan&repo=mini-spring&theme=flag-india&hide_border=false" />
</a>
<a href="https://github.com/Raray-chuan/springboot-kerberos-hikari-impala">
  <img height="125px" src="https://github-readme-stats.vercel.app/api/pin/?username=Raray-chuan&repo=springboot-kerberos-hikari-impala&theme=flag-india&hide_border=false" />
</a>
</div>
<br>

<div align="">
<a href="https://github.com/Raray-chuan/quality-manage">
  <img height="125px" src="https://github-readme-stats.vercel.app/api/pin/?username=Raray-chuan&repo=quality-manage&theme=flag-india&hide_border=false" />
</a>
<a href="https://github.com/Raray-chuan/HikariCP-4.0.3">
  <img height="125px" src="https://github-readme-stats.vercel.app/api/pin/?username=Raray-chuan&repo=HikariCP-4.0.3&theme=flag-india&hide_border=false" />
</a>
</div>
<br>

## About Me✒️🙋‍♂️️
- Name: 兮川
- Nickname：Xichuan
- From: Nanjing City, JiangSu Province in China
- Favorite Programming Language
  - Java
  - Python
  - Scala
- My Wechat
<table  style="right: 200px">
    <tr>
      <td align="center" style="width: 200px;">
        <a href="https://github.com/Raray-chuan">
          <img src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/qrcode-for-xichuan.jpg" style="width: 130px;"><br>
          <sub>Subscription Account</sub>
        </a><br>
      </td>
      <td align="center" style="width: 200px;">
        <a href="https://github.com/Raray-chuan">
          <img src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/qrcode-for-it_fushang.jpg" style="width: 130px;"><br>
          <sub>Wechat</sub>
        </a><br>
      </td>
    </tr>
</table>    
<br>

## Statistics🍉🍓
<p align="center">
    <a title="github" target="_blank" href="https://github.com/raray-chuan"><img src="https://img.shields.io/badge/dynamic/json?label=GitHub&suffix=%20followers&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3Dgithub%26queryKey%3Draray-chuan&labelColor=282c34&color=353940&logo=github&longCache=true" ></a>&emsp;
    <img src="https://visitor-badge.glitch.me/badge?page_id=raray-chuan" />&emsp; 
    <a href="https://blog.csdn.net/zc_ad/"><img src="https://img.shields.io/badge/CSDN-博客-blue"/></a>&emsp;
    <a href="https://space.bilibili.com/276402816/"><img src="https://img.shields.io/badge/bilibili-哔哩哔哩-ff69b4"/></a>&emsp;
</p>

<div align="center">
<span>&emsp;&emsp;</span>
    <img height="150px"  alt="Xichuan's Stats" src="https://github-readme-stats.vercel.app/api?username=raray-chuan" /><span>&emsp;&emsp;</span>
    <img height="150px" src="https://github-readme-streak-stats.herokuapp.com/?user=raray-chuan" />
    <!--<img height="150px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=raray-chuan&layout=compact&langs_count=8" />-->
<span>&emsp;&emsp;</span>
</div>

<div align="center">
    <img src="https://raw.githubusercontent.com/raray-chuan/raray-chuan/main/img/github-contribution-grid-snake.svg" >
</div>
<br>


## TODO🕥📡
- xichuan_note: add spring and hadoop notes
  <br>


## Love GitHub⛅⛱️
<div align="center"><img width="50%" src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/github-pic.gif"/></div>
<div align="center"><img src="https://raw.githubusercontent.com/Raray-chuan/xichuan_blog_pic/main/img/inner/bottom.png" /></div>




